const express = require('express');
const morgan = require('morgan');
const cors = require('cors');
const app = express();

//settings
app.set('puerto', process.env.PORT || 3000);
app.set('nombreApp', 'Gestión de empleados');
app.use(morgan('dev'));

app.use(express.json());
app.use(cors());
let instance = null;

module.exports = {
    getInstance: function() {
        if (!instance) {
            instance = app;
            require('./database');
            app.use('/api/empleados', require('./routes/empleados.routes'));
        }
        return instance;
    }
};
